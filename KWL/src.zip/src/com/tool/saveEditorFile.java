package com.tool;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class saveEditorFile {
	
	public static void save(String realpath, HttpServletRequest request, HttpServletResponse response) throws Exception{
		PrintWriter out;
		out = response.getWriter();
		String name = request.getParameter("name");
		System.out.println("save:" + realpath + "editor/data/"+name+".ogeditor");
		File file = new File(realpath + "editor/data/"+name+".ogeditor");
		if(!file.exists()) file.createNewFile();
		FileWriter writer = new FileWriter(realpath + "editor/data/"+name+".ogeditor");
		
		writer.write(request.getParameter("xml"));
		writer.close(); 
		out.print("OK");
	}
	
	public static void read(String realpath, HttpServletRequest request, HttpServletResponse response) throws Exception{
		String filename = request.getParameter("filename");
		File file = new File(realpath + "editor/data/"+ filename+".ogeditor");
		if(file.exists()){
			BufferedReader br 
			= new BufferedReader(
					new InputStreamReader( 
							new FileInputStream(file)));
			StringBuilder sb = new StringBuilder();
			String line = "";
			while( (line = br.readLine())!=null){
				sb.append(line);
			}
			System.out.println("read:" + realpath + "editor/data/"+filename+".ogeditor");
			System.out.println(sb.toString());
			response.getWriter().write(sb.toString());
		}else{
			response.getWriter().write("error");
		}
		
	}
}
