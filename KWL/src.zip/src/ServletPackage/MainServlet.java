package ServletPackage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.store.LockObtainFailedException;
import org.lxh.smart.SmartUpload;
import org.lxh.smart.SmartUploadException;

import ServletPackage.ConnectionMan;
import ServletPackage.MyConnection;
import ServletPackage.MyResultSet;
import ServletPackage.DataBaseMan;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.data.get.crawler;
import com.index_search.IndexFile;
import com.index_search.SearchFile;
import com.tool.saveEditorFile;

/**
 * Servlet implementation class MainServlet
 */
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static DataBaseMan dbMan;
	private crawler c;
	public static ConnectionMan connectionMan; 
	public static long outTime;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MainServlet() {
        super();
        // TODO Auto-generated constructor stub
        dbMan = new DataBaseMan();
        outTime=1000*60*30;
        
		if (dbMan==null)
			ErrorLog("dbMan is null In EnergyServlet!");
		connectionMan = new ConnectionMan();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		handleReq(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		handleReq(request,response);
	}
	
	void ErrorLog(String s){
		System.err.print("Error: "+s);
	}
	void Log(String s){
		System.out.print(s);
	}
	
	private void handleReq(HttpServletRequest request, HttpServletResponse response){
		String type = request.getParameter("type");
		System.out.println(" type "+type);
		String projectpath = this.getServletConfig().getServletContext().getRealPath("/");
		
		//����ϵͳ���½�������   ��û��Ҫʹ�ã�
		if("0".compareTo(type)==0){
			StartIndex(request,response,projectpath);
		}
		//�����ļ�
		else if("1".compareTo(type)==0){
			StartSearch(request,response,projectpath);
		}
		//����ѡ�е��ļ�
		else if("2".compareTo(type)==0){
			StartDownload(request,response,projectpath);
		}
		//���ѡ�е��ļ�
		else if("3".compareTo(type)==0){
			StartScan(request,response,projectpath);
		}
		//ץȡ��Ӧ���ļ�
		else if("4".compareTo(type)==0){
			String url = request.getParameter("url");
			c = new crawler(url,projectpath+"owl/online");
			String cookie = request.getParameter("cookie");
			ArrayList<String[]> newfiles = c.start(cookie);		
		}
		//ֹͣץȡ
		else if("5".compareTo(type)==0){
			c.stop();
		}
		//�û���¼
		else if("6".compareTo(type)==0){
			login(request,response);
		}
		//�û�ע��
		else if("7".compareTo(type)==0){
			Register(request, response);
		}
		//�����������������Ҫ����¼״̬
		//�ϴ��Լ���֪��
		else if("8".compareTo(type)==0){
			System.out.println("happen");
			String param[] = new String[2];
			boolean flag = this.CheckLoginState(request, param);
			if(!flag){
				System.out.println("notEqual");
				try {
					response.getWriter().write("login?");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else
			{
				System.out.println("equal");
				FileUpload.upload( projectpath, this, dbMan, param[0], param[1], request, response);
			}
		}
		//�鿴�Լ���֪��
		else if("9".compareTo(type)==0){
			
		}
		//���ܴ洢�༭�ļ�������
		else if("11".compareTo(type)==0){
			try {
				new saveEditorFile().save(projectpath, request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if("12".compareTo(type)==0){
			try {
				new saveEditorFile().read(projectpath, request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	private void StartIndex(HttpServletRequest request, HttpServletResponse response,String realpath){
		try {
			try {
				new IndexFile().IndexFromInternet(realpath,realpath+"/owl/online/tempfile.txt");
			} catch (CorruptIndexException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (LockObtainFailedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.getWriter().write("index has been builded");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void StartSearch(HttpServletRequest request, HttpServletResponse response,String realpath){
		long start = new Date().getTime();
		String field = request.getParameter("field");
		String value = request.getParameter("value");
		ArrayList<String[]> al = new ArrayList<String[]>();
		try {
			System.out.println("search");
			new SearchFile(realpath).search(al,field, value, 0);
			/**
			 * ���ò����ش�
			 */
			request.setAttribute("key", value);
			request.setAttribute("hitsnum", al.size());
			request.setAttribute("hits", new Integer(al.size()).toString());
			for(int i=0;i<al.size();i++){
				request.setAttribute("hit"+i, al.get(i)[0]+"|"+al.get(i)[1]);
				request.setAttribute("con"+i, al.get(i)[2] );
				request.setAttribute("pos"+i, al.get(i)[3] );
//				System.out.println(al.get(i)[1]+"|"+al.get(i)[2]);
			}
			long end = new Date().getTime();
			request.setAttribute("time", end-start);
			this.getServletContext().getRequestDispatcher("/present.jsp").forward(request, response);
			
		} catch (CorruptIndexException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void StartDownload(HttpServletRequest request, HttpServletResponse response,String realpath){
		String filename=request.getParameter("filename");
		String pos = request.getParameter("pos");
		
		try {
			SmartUpload smart = new SmartUpload();
			smart.initialize(this.getServletConfig(), request, response);
			smart.setContentDisposition(null);
			if (pos.compareTo("online")==0){
				smart.downloadFile(realpath+"/owl/online/"+filename);
			}else{
				smart.downloadFile(realpath+"/owl/local/"+filename);
			}
			System.out.println("download");
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SmartUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private void StartScan(HttpServletRequest request, HttpServletResponse response,String realpath){
		String filename=request.getParameter("filename");
		String pos = request.getParameter("pos");
		
		File file ;
		if(pos.compareTo("online")==0){
			file = new File(realpath+"/owl/online/"+filename);
		}else{
			file = new File(realpath+"/owl/local/"+filename);
		}
		try {
			FileInputStream fis = new FileInputStream(file);
			InputStreamReader isr = new InputStreamReader(fis);
			BufferedReader br = new BufferedReader(isr); 
			StringBuilder sb = new StringBuilder();
			String line="";
			while((line = br.readLine())!=null){
				sb.append(line);
			}
			response.getWriter().write(sb.toString());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("scan");	
	}
	//�û���¼
	public void login(HttpServletRequest request, HttpServletResponse response){
		String user = request.getParameter("username");
		String psw = request.getParameter("password");
		//ת���ɼ��ܺ���ַ���
		System.out.println("what happen");
		String password = MyMD5(psw.getBytes());
		MyResultSet rs = dbMan.SelectCond("user_profile", "userName="+"'"+user+"'");
		try {
			if (!rs.first()) {
				response.getWriter().write("usr err");
				return;
			}
			if (rs.getString(3).compareTo(password)==0){
				String session = MyMD5((user+System.currentTimeMillis()+"").getBytes());
				MyConnection myConn = new MyConnection(user,session,System.currentTimeMillis());
				if (connectionMan.Get(user)!=null) connectionMan.Remove(user);
				connectionMan.Put(myConn);
				response.getWriter().write(session+"&username="+user);
				
				Log("us="+user+" Se="+session);
			}else{
				System.out.println("no equal");
				response.getWriter().write("failed");
			}
			rs.close();
		}  catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		
		
	}
	
	private boolean CheckLoginState(HttpServletRequest request, String[] param){
		String name = request.getParameter("username");
		String session = request.getParameter("session");
		MyConnection myConn = connectionMan.Get(name);
		param[0] = name;
		param[1] = session+"&username="+name;
		
		System.out.println("client:"+session+" server:"+ name);
		if (myConn==null){
			return false;
		}else if (myConn.session.compareTo(session)!=0){
			return false;
		}else if (System.currentTimeMillis()-myConn.lastTime>outTime){
			return false;
		}
		return true;
	}
	
	private void Register(HttpServletRequest request, HttpServletResponse response){
		String name = request.getParameter("username");
		String psw = request.getParameter("password");
		String[] zd={"userName","password"};
		String[] vals={"'"+name+"'","'"+MyMD5(psw.getBytes())+"'"};
		
		MyResultSet rs = dbMan.SelectCond("user_profile", "userName='"+name+"'");
		String reS="0";
			if (rs.first()){
				reS="fail";
			}
			else{
				boolean reval = dbMan.InsertRow("user_profile", zd, vals);
				if (reval){
				reS="success!";
				}
			}
			rs.close();

		try {
			response.getWriter().write(reS);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	//md5��������
	public String MyMD5(byte[] source){
		String s = null;
        char hexDigits[] = { // �������ֽ�ת���� 16 ���Ʊ�ʾ���ַ�
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            md.update(source);
            byte tmp[] = md.digest();          // MD5 �ļ�������һ�� 128 λ�ĳ�������
            // ���ֽڱ�ʾ���� 16 ���ֽ�
            char str[] = new char[16 * 2];   // ÿ���ֽ��� 16 ���Ʊ�ʾ�Ļ���ʹ�������ַ���
            // ���Ա�ʾ�� 16 ������Ҫ 32 ���ַ�
            int k = 0;                                // ��ʾת������ж�Ӧ���ַ�λ��
            for (int i = 0; i < 16; i++) {    // �ӵ�һ���ֽڿ�ʼ���� MD5 ��ÿһ���ֽ�
                // ת���� 16 �����ַ���ת��
                byte byte0 = tmp[i];  // ȡ�� i ���ֽ�
                str[k++] = hexDigits[byte0 >>> 4 & 0xf];  // ȡ�ֽ��и� 4 λ������ת��, 
                // >>> Ϊ�߼����ƣ�������λһ������
                str[k++] = hexDigits[byte0 & 0xf];   // ȡ�ֽ��е� 4 λ������ת��
            }
            s = new String(str);  // ����Ľ��ת��Ϊ�ַ���

        } catch (Exception e) {
            e.printStackTrace();
        }
        return s;
	}
}
