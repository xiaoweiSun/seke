package ServletPackage;

import java.io.IOException;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.store.LockObtainFailedException;
import org.lxh.smart.SmartUpload;
import org.lxh.smart.SmartUploadException;

import ServletPackage.DataBaseMan;
import ServletPackage.MyResultSet;
import ServletPackage.MainServlet;
import com.index_search.*;

public class FileUpload {

	public static void upload(String realpath, MainServlet servlet ,DataBaseMan dbMan, String username, String cookie, HttpServletRequest req, HttpServletResponse resp)
	{
		System.out.println("���ڴ����ļ�");
		SmartUpload smart = new SmartUpload();
		try {
			smart.initialize(servlet.getServletConfig(), req, resp);
			smart.upload();
			System.out.println("�ϴ��ɹ�");
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SmartUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//����ȷ����Ҫ�����ݿ��в����������
		String ele[] = {"title","description","tag","classification","reference","version","filepath","userName"};	
		
		Vector filelist = new Vector();
		//��ÿ���ϴ��ļ����д���
		for(int i=0;i<smart.getFiles().getCount();i++){
			System.out.println("upload "+smart.getFiles().getFile(i).getFilePathName());
			org.lxh.smart.File file = smart.getFiles().getFile(i);
			if(file.isMissing())continue;
			try {
				file.saveAs("/owl/local/"+file.getFileName(),SmartUpload.SAVE_AUTO);
				String value[] = new String[ele.length];
				for(int j=0;j<ele.length-2;j++)
				{
					value[j] = "'"+smart.getRequest().getParameter(ele[j])+"'";
					System.out.println(value[j]);
				}
				//ÿ�ζ����ӵ�i���ļ���·����Ϣ  ���ҽ��û�����Ϣ��¼����
				value[ele.length-2] = "'"+smart.getFiles().getFile(i).getFileName()+"'";
				value[ele.length-1] = "'"+username+"'";
				dbMan.InsertRow("owl_profile", ele, value);
				filelist.add(realpath+"/owl/local/"+smart.getFiles().getFile(i).getFileName());
				
			} catch (SmartUploadException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		String files[] = new String[filelist.size()];
		for(int i = 0; i < files.length; i++){
			files[i] = (String) filelist.get(i);
		}
		//��������ϴ��ļ�������
		try {
			String virtualpath = req.getScheme()+"://"
							+ req.getServerName()+":"
							+ req.getServerPort();
			new IndexFile().IndexFromLocal(virtualpath, realpath, files);
		} catch (CorruptIndexException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (LockObtainFailedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//ҳ����תʵ��
		resp.setStatus(HttpServletResponse.SC_MOVED_PERMANENTLY);
		resp.setHeader("Location","publish.jsp?session="+cookie);
	
	}
}
