package ServletPackage;

public class Config {
	public static String mysqlURL = "jdbc:mysql://localhost:3306/kwl_database";
	public static String mysqlUser = "root";
	public static String mysqlPassword = "root";
	
	public static boolean debug = false;//ȷ������debug״̬
	public static void D(String str){
		if(debug){
			System.out.println(str);
		}
	}
}
